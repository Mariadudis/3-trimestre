const cliente = {
    nome: "André",
    idade: 32,
    cpf: "1122233345",
    email: "andre@dominio.com"
};
console.log(`O nome do cliente é ${cliente.nome} e essa pessoa tem ${cliente.idade} anos.`)
console.log(`Os três primeiros digitos do cpf são ${cliente.cpf}`)
console.log(`O endereço de email é ${cliente.email}`)
