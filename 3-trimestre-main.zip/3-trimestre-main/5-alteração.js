const pessoa = {
    nome: "Sthéfanie",
    profissão: "programadora",
};

console.log(pessoa.nome);
console.log(pessoa.telefone);

pessoa.telefone = "11 2223333444";

console.log(pessoa.telefone);

pessoa.nome = "Luma Silva";;

console.log(pessoa)

const NovaPessoa = {
    nome: "Théfa",
};
