const cliente = {
    nome: "João",
    idade: 24,
    email: "joao@firma.com",
    telefone: ["123456789", "987654321"],
};
cliente.endereco = {
    rua: "R. Joseph Climber",
    numero: 1819,
    apartamento: true,
    complemento: "ap 123",
};;

console.log(cliente);
console.log(cliente.endereco)