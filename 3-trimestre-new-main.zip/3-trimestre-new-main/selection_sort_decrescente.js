/**
 *@param {number []} arr - o array a ser condenado.
 *@return {number []} - o array ordenado em ordem crescente.
*/

function selectionSortAscending(arr){
    let n = arr.length;
    for (let i = 0; i < n - 1; i++){
        let minIndex = j;
    }
}

if (minIndex !== i){
    let temp = arr[i];
    arr[i] = arr[minIndex];
    arr[minIndex] = temp;
}
 return arr;

 let arrayDesc = [64, 24, 12, 22, 11]
 console.log("Array original:", arrayDesc);
 console.log("Array ordenado em ordem decrescente:", selectionSortAscending(arrayDesc))